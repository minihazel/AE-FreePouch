exports.mod = (mod_info) => {
    logger.logInfo("[MOD] Loading: FreeContainers");
	let modFolder = `user/mods/hazelify-FreeContainers-1.0.1`
	// Getting local config file to fetch the mod's filters
    let PathResolver = global.internal.path.resolve
	let baseConfig = fileIO.readParsed(PathResolver(`${modFolder}/config.json`))
	// Getting the cached items.json to fetch all containers in-game
	let base = fileIO.readParsed(global.db.user.cache.items)
	// Introducing global variables for inserting info
	let cases = ``
	let counter = ``
	let originalID = ``
	let originalName = ``
	let originalH = ``
	let originalV = ``
	// Looping through all containers in config.json
	for (let item in baseConfig.containers) {
		var _container = baseConfig.containers[item]
		// Looping through all containers in the cache items.json
		for (let item in base.data) {
			var _case = base.data[item]
			// If container _id in cache items.json matches the container _id in config.json
			if (_case._id === _container._id) {
				originalH = _case._props.Grids[0]._props.cellsH
				originalV = _case._props.Grids[0]._props.cellsV
				originalID = _container._id
				originalName = _container._name
				cases = _case._name
				logger.logInfo(`[MOD] FOUND CUSTOMIZED ITEM:   "${_case._id}" (${_case._name})\n[MOD] APPLYING NEW FILTER (Adding ${_container.UpdatedFilter.length} items)`)
				// Append the array in config.json to the array for the same item in the cache items.json
				_case._props.Grids[0]._props.filters[0].Filter.push.apply(_case._props.Grids[0]._props.filters[0].Filter, _container.UpdatedFilter)
				if (_container.EnableCustomCells = true) {
					_case._props.Grids[0]._props.cellsH = _container.HorizontalSlotCount
					_case._props.Grids[0]._props.cellsV = _container.VerticalSlotCount
					placeHolderH = _case._props.Grids[0]._props.cellsH
					placeHolderV = _case._props.Grids[0]._props.cellsV
				} else {
					placeHolderH = _container.HorizontalSlotCount
					placeHolderV = _container.VerticalSlotCount
				}
			}
		}
		// Loop through all the items in specified container's array in config.json, then appending it to a list for simplified logging
		for (var i = 0; i < _container.UpdatedFilter.length; i++) {
			counter = `"${_container.UpdatedFilter[i]}"`
			console.log(counter)
		}
		// Redundant NewLine for easier readability in the console and log
		console.log(``)
		console.log(`[MOD] APPLYING SLOT SIZE TO ITEM:  ${_container._id} (${_container._name}) :   NEW (${placeHolderH}x${placeHolderV})   OLD (${originalH}x${originalV})\n`)
	}
	// Write the new info to the cache items.json using the base data
	fileIO.write(global.db.user.cache.items, base)
	logger.logSuccess(`[MOD] FreeContainers Applied; ${Object.keys(baseConfig.containers).length} containers affected`);
}